BMW Official PWA Package

앱 이름:
BMW

업로드 대상:
https://bsk1013.github.io/bmw2026/

업로드 파일:
- index.html
- manifest.webmanifest
- service-worker.js
- icons 폴더 전체

아이콘 기준:
- 사용자가 제공한 BI logo base64 텍스트 파일 기준
- 원본 크기: 158 x 160
- 원본 저장: icons/bi-logo-original.png

참고:
- GitHub Pages bmw2026 경로에 위 파일들을 그대로 업로드하세요.
- 기존 파일과 교체 업로드하면 됩니다.
- 서비스워커 캐시가 남으면 앱 재실행/새로고침 후 반영됩니다.
